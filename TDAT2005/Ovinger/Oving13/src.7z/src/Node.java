public class Node {
    Edge e1;
    Object d;
    double longitude;
    double latitude;
    double cos_breadth;
}
